<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Chauffeur Email Template</title>
     <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;1,300;1,400;1,500;1,600;1,700;1,800&family=Rajdhani:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style type="text/css">
        body{
            font-family: 'Rajdhani', sans-serif !important;
        }
    </style>
</head>

<body style="padding: 0px;margin: 0px;">
    <div style="max-width:100%,width:100%;padding: 0px;">
        <table style="width: 100%;">
            <tbody>
                <tr>
                    <td>
                        <table style="width:700px;border: 1px solid gray;margin-left: auto;margin-right: auto;padding: 0px;border-spacing: 0px;">
                            <tr>
                                <td style="padding: 0px;">
                                    <div style="background-image:url(https://res.cloudinary.com/dyidzfrja/image/upload/v1680435519/personal/headimg_j9ctix.jpg);text-align: center;    background-repeat: no-repeat;background-position: center;height: 40vh;background-size: cover;">
                                        <img src="https://res.cloudinary.com/dyidzfrja/image/upload/v1680436034/personal/logo_kmzx1h.png" style="width: 40%; transform: translateY(-10px);">
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td style="padding-left:50px;padding-right:50px;padding-top:0px;">
                                    <br>
                                    <p style="color: #777777;">
                                        <b>Dear</b> {{$details['card_name']}},
                                    </p>
                                    <p style="color: #777777;">
                                        This is to inform you that your Payment details has been received. </p>
                                    <p style="color: #777777;">
                                        The details of your payment are given below:
                                    </p>
                                </td>
                            </tr>
                            <tr>
                                <td style="padding:50px;">
                                    <table cellspacing="0" cellpadding="0" width="100%" >
                                        <tbody>
                                            <tr>
                                                <td style="padding: 0px 0px 5px 0px; font-weight: bold; color: #444444; border-bottom: dotted 1px #aaaaaa; text-transform: uppercase;">General</td>
                                            </tr>
                                            <tr>
                                                <td style="padding: 0px; height: 15px;"></td>
                                            </tr>
                                            <tr>
                                                <td style="padding: 0px;">
                                                    <table cellspacing="0" cellpadding="0">
                                                        <tbody>
                                                            <tr>
                                                                <td style="padding: 0px 5px 0px 0px; width: 250px; vertical-align: top;color: #777777">Card Name</td>
                                                                <td style="padding: 0px 0px 0px 5px; width: 300px; vertical-align: top;color: #777777">{{$details['card_name']}}</td>
                                                            </tr>
                                                            <tr>
                                                                <td style="padding: 0px 5px 0px 0px; width: 250px; vertical-align: top;color: #777777">Amount</td>
                                                                <td style="padding: 0px 0px 0px 5px; width: 300px; vertical-align: top;color: #777777">£ {{$details['amount']}}</td>
                                                            </tr>
                                                            <tr>
                                                                <td style="padding: 0px 5px 0px 0px; width: 250px; vertical-align: top;color: #777777">Date</td>
                                                                <td style="padding: 0px 0px 0px 5px; width: 300px; vertical-align: top;color: #777777">{{$details['date']}}</td>
                                                            </tr>

                                                        </tbody>
                                                    </table>
                                                </td>
                                            </tr>

                                        </tbody>
                                    </table>
                                </td>
                            </tr>
                            <tr>
                                <td style="padding-left:50px;padding-right:50px;">
                                    <table style="font-family:'Montserrat',sans-serif" cellpadding="0" cellspacing="0" width="100%" border="0">
                                        <tbody>
                                            <tr>
                                                <td style="word-break:break-word;padding:10px;font-family:'Montserrat',sans-serif" align="left">
                                                   <hr style="width:84%;">
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                    <table style="font-family:'Montserrat',sans-serif" cellpadding="0" cellspacing="0" width="100%" border="0">
                                        <tbody>
                                            <tr>
                                                <td style="word-break:break-word;padding:0px;font-family:'Montserrat',sans-serif" align="left">
                                                    <div style="line-height:140%;text-align:left;word-wrap:break-word">
                                                        <p style="font-size: 14px; line-height: 140%; text-align: left;color: #777777;">
                                                            If any of the above information is incorrect or you need to modify any details, please contact us at <strong>+44 203 9300286</strong>. for more information visit our website
                                                            <span style="font-size: 14px; line-height: 19.6px;">
                                                                <strong>
                                                                    <span style="color: #000000; font-size: 14px; line-height: 19.6px;"><a  href="https://epicridelondon.com/"  style="color: #000000;" target="_blank">Epic Ride London.</a></span>
                                                                </strong>
                                                            </span>
                                                            <br />
                                                            &nbsp;<br />
                                                            Warm Regards,<br />
                                                            Team Epic Ride.
                                                        </p>
                                                    </div>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </td>
                            </tr>
                            <tr>
                                <td style="padding: 30px 30px;
                                    background-image: url(https://res.cloudinary.com/dyidzfrja/image/upload/v1680435969/personal/london_mtl9u1.png);
                                    background-position: bottom;
                                    background-repeat: no-repeat;
                                    background-size: contain" bgcolor=" #C99B20">
                                    <table style="" role="presentation" cellpadding="0" cellspacing="0" width="100%" border="0">
                                        <tbody>
                                            <tr>
                                                <td style="word-break: break-word; padding: 0px 0px; " align="left">
                                                    <div style="color: #fff; line-height: 140%; text-align: center; word-wrap: break-word;">
                                                        <p style="font-size: 14px; line-height: 140%;">
                                                            <strong><span style="font-size: 18px; line-height: 25.2px;">EPIC RIDE LONDON.</span></strong>
                                                        </p>
                                                    </div>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>

                                    <table style="" role="presentation" cellpadding="0" cellspacing="0" width="100%" border="0">
                                        <tbody>
                                            <tr>
                                                <td style="word-break: break-word; padding: 0px 10px 0 10px; " align="left">
                                                    <div style="color: #fff; line-height: 180%; text-align: center; word-wrap: break-word;">
                                                        <p style="font-size: 14px; line-height: 180%;">
                                                        450 Bath Rd, Longford, Heathrow, UK. UB7 0EB</p>
                                                        <p style="font-size: 14px; line-height: 180%;">+44 203 9300286</p>
                                                    </div>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                    <table style="" role="presentation" cellpadding="0" cellspacing="0" width="100%" border="0">
                                        <tbody>
                                            <tr>
                                                <td style="word-break: break-word; padding: 10px; " align="left">
                                                    <div align="center">
                                                        <div style="display: table; max-width: 211px;">
                                                            <table align="left" border="0" cellspacing="0" cellpadding="0" width="32" height="32" style="border-collapse: collapse; table-layout: fixed; border-spacing: 0; vertical-align: top; margin-right: 21px;">
                                                                <tbody>
                                                                    <tr style="vertical-align: top;">
                                                                        <td align="left" valign="middle" style="word-break: break-word; border-collapse: collapse !important; vertical-align: top;">
                                                                            <a
                                                                                href=""
                                                                                title="Facebook"
                                                                                target="_blank"
                                                                            >
                                                                                <img
                                                                                src="https://res.cloudinary.com/dyidzfrja/image/upload/v1680382500/personal/fb_t8p2fo.png"
                                                                                    alt="Facebook"
                                                                                    title="Facebook"
                                                                                    width="32"
                                                                                    style="outline: none; text-decoration: none; clear: both; display: block !important; border: none; height: auto; float: none; max-width: 32px !important;"
                                                                                    class="CToWUd"
                                                                                    data-bit="iit"
                                                                                />
                                                                            </a>
                                                                        </td>
                                                                    </tr>
                                                                </tbody>
                                                            </table>

                                                            <table align="left" border="0" cellspacing="0" cellpadding="0" width="32" height="32" style="border-collapse: collapse; table-layout: fixed; border-spacing: 0; vertical-align: top; margin-right: 21px;">
                                                                <tbody>
                                                                    <tr style="vertical-align: top;">
                                                                        <td align="left" valign="middle" style="word-break: break-word; border-collapse: collapse !important; vertical-align: top;">
                                                                            <a
                                                                                href=""
                                                                                title="Instagram"
                                                                                target="_blank"
                                                                            >
                                                                                <img
                                                                                src="https://res.cloudinary.com/dyidzfrja/image/upload/v1680382541/personal/inst_mf8kyt.png"
                                                                                    alt="Instagram"
                                                                                    title="Instagram"
                                                                                    width="32"
                                                                                    style="outline: none; text-decoration: none; clear: both; display: block !important; border: none; height: auto; float: none; max-width: 32px !important;"
                                                                                    class="CToWUd"
                                                                                    data-bit="iit"
                                                                                />
                                                                            </a>
                                                                        </td>
                                                                    </tr>
                                                                </tbody>
                                                            </table>

                                                            <table align="left" border="0" cellspacing="0" cellpadding="0" width="32" height="32" style="border-collapse: collapse; table-layout: fixed; border-spacing: 0; vertical-align: top; margin-right: 21px;">
                                                                <tbody>
                                                                    <tr style="vertical-align: top;">
                                                                        <td align="left" valign="middle" style="word-break: break-word; border-collapse: collapse !important; vertical-align: top;">
                                                                            <a
                                                                                href=""
                                                                                title="Youtube"
                                                                                target="_blank"
                                                                            >
                                                                                <img
                                                                                    src="https://res.cloudinary.com/dyidzfrja/image/upload/v1680435650/personal/youtube_l7sjo4.png"
                                                                                    alt="Youtube"
                                                                                    title="Youtube"
                                                                                    width="32"
                                                                                    style="outline: none; text-decoration: none; clear: both; display: block !important; border: none; height: auto; float: none; max-width: 32px !important;"
                                                                                    class="CToWUd"
                                                                                    data-bit="iit"
                                                                                />
                                                                            </a>
                                                                        </td>
                                                                    </tr>
                                                                </tbody>
                                                            </table>

                                                            <table align="left" border="0" cellspacing="0" cellpadding="0" width="32" height="32" style="border-collapse: collapse; table-layout: fixed; border-spacing: 0; vertical-align: top; margin-right: 0px;">
                                                                <tbody>
                                                                    <tr style="vertical-align: top;">
                                                                        <td align="left" valign="middle" style="word-break: break-word; border-collapse: collapse !important; vertical-align: top;">
                                                                            <a
                                                                                href=""
                                                                                title="Twitter"
                                                                                target="_blank"
                                                                            >
                                                                                <img
                                                                                    src="https://res.cloudinary.com/dyidzfrja/image/upload/v1680382589/personal/twitter_fiog9p.png"
                                                                                    alt="Twitter"
                                                                                    title="Twitter"
                                                                                    width="32"
                                                                                    style="outline: none; text-decoration: none; clear: both; display: block !important; border: none; height: auto; float: none; max-width: 32px !important;"
                                                                                    class="CToWUd"
                                                                                    data-bit="iit"
                                                                                />
                                                                            </a>
                                                                        </td>
                                                                    </tr>
                                                                </tbody>
                                                            </table>
                                                        </div>
                                                    </div>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>

                                    <table style="" role="presentation" cellpadding="0" cellspacing="0" width="100%" border="0">
                                        <tbody>
                                            <tr>
                                                <td style="word-break: break-word; padding: 10px; " align="left">
                                                    <table
                                                        height="0px"
                                                        align="center"
                                                        border="0"
                                                        cellpadding="0"
                                                        cellspacing="0"
                                                        width="82%"
                                                        style="border-collapse: collapse; table-layout: fixed; border-spacing: 0; vertical-align: top; border-top: 1px solid #fff;"
                                                    >
                                                        <tbody>
                                                            <tr style="vertical-align: top;">
                                                                <td style="word-break: break-word; border-collapse: collapse !important; vertical-align: top; font-size: 0px; line-height: 0px;">
                                                                    <span>&nbsp;</span>
                                                                </td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>

                                    <table style="" role="presentation" cellpadding="0" cellspacing="0" width="100%" border="0">
                                        <tbody>
                                            <tr>
                                                <td style="word-break: break-word; padding: 10px; " align="left">
                                                    <div style="text-align: center;">
                                                        <a
                                                            href="https://epicridelondon.com/services"
                                                            style="padding: 5px 15px; display: inline-block; color: #fff;  font-size: 14px; text-decoration: none;"
                                                            target="_blank"
                                                        >
                                                            Services
                                                        </a>

                                                        <a
                                                            href="https://epicridelondon.com/fleets"
                                                            style="padding: 5px 15px; display: inline-block; color: #fff;  font-size: 14px; text-decoration: none;"
                                                            target="_blank"
                                                        >
                                                            Our Fleets
                                                        </a>

                                                        <a
                                                            href="https://epicridelondon.com/about-us"
                                                            style="padding: 5px 15px; display: inline-block; color: #fff;  font-size: 14px; text-decoration: none;"
                                                            target="_blank"
                                                        >
                                                            About Us
                                                        </a>

                                                        <a
                                                            href="https://epicridelondon.com/terms-&-conditions"
                                                            style="padding: 5px 15px; display: inline-block; color: #fff;  font-size: 14px; text-decoration: none;"
                                                            target="_blank"
                                                        >
                                                            Terms &amp; Conditions
                                                        </a>
                                                    </div>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>

                                    <table style="" role="presentation" cellpadding="0" cellspacing="0" width="100%" border="0">
                                        <tbody>
                                            <tr>
                                                <td style="word-break: break-word; padding: 10px; " align="left">
                                                    <table
                                                        height="0px"
                                                        align="center"
                                                        border="0"
                                                        cellpadding="0"
                                                        cellspacing="0"
                                                        width="82%"
                                                        style="border-collapse: collapse; table-layout: fixed; border-spacing: 0; vertical-align: top; border-top: 1px solid #fff;"
                                                    >
                                                        <tbody>
                                                            <tr style="vertical-align: top;">
                                                                <td style="word-break: break-word; border-collapse: collapse !important; vertical-align: top; font-size: 0px; line-height: 0px;">
                                                                    <span>&nbsp;</span>
                                                                </td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>

                                    <table style="" role="presentation" cellpadding="0" cellspacing="0" width="100%" border="0">
                                        <tbody>
                                            <tr>
                                                <td style="word-break: break-word; padding: 0px 10px 13px; " align="left">
                                                    <div style="color: #fff; line-height: 180%; text-align: center; word-wrap: break-word;">
                                                        <p style="font-size: 14px; line-height: 180%;font-weight: bold;">© 2023 All Rights Reserved</p>
                                                    </div>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </td>
                            </tr>

                        </table>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</body>

</html>
