<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Chauffeur Email Template</title>
     <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;1,300;1,400;1,500;1,600;1,700;1,800&family=Rajdhani:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style type="text/css">
        body{
            font-family: 'Rajdhani', sans-serif !important;
        }
    </style>
</head>

<body style="padding: 0px;margin: 0px;">
    <div style="max-width:100%,width:100%;padding: 0px;">
        <table style="width: 100%;">
            <tbody>
                <tr>
                    <td>
                        <table style="width:700px;border: 1px solid gray;margin-left: auto;margin-right: auto;padding: 0px;border-spacing: 0px;">
                            <tr>
                                <td style="padding: 0px;">
                                    <div style="background-image:url(https://res.cloudinary.com/dyidzfrja/image/upload/v1680435519/personal/headimg_j9ctix.jpg);text-align: center;    background-repeat: no-repeat;background-position: center;height: 40vh;background-size: cover;">
                                        <img src="https://res.cloudinary.com/dyidzfrja/image/upload/v1680436034/personal/logo_kmzx1h.png" style="width: 40%; transform: translateY(-10px);">
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td style="padding-left:50px;padding-right:50px;padding-top:0px;">
                                    <br>
                                    <p style="color: #777777;font-family: Arial;">
                                        <b>Dear</b> {{$details['FirstName']}} {{$details['LastName']}},
                                    </p>
                                    <p style="color: #777777;font-family: Arial;">
                                        This is to inform you that your booking details has been received and waiting for confirmation. </p>
                                    <p style="color: #777777;font-family: Arial;">
                                        The details of your booking are given below:
                                    </p>
                                </td>
                            </tr>
                            <tr>
                                <td style="padding:50px;">
                                    <table cellspacing="0" cellpadding="0" width="100%" >
                                        <tbody>
                                            <tr>
                                                <td style="padding: 0px 0px 5px 0px; font-weight: bold; color: #444444; border-bottom: dotted 1px #aaaaaa; text-transform: uppercase;font-family: Arial;">General</td>
                                            </tr>
                                            <tr>
                                                <td style="padding: 0px; height: 15px;"></td>
                                            </tr>
                                            <tr>
                                                <td style="padding: 0px;">
                                                    <table cellspacing="0" cellpadding="0">
                                                        <tbody>
                                                            <tr>
                                                                <td style="padding: 0px 5px 0px 0px; width: 250px; vertical-align: top;color: #777777">Title</td>
                                                                <td style="padding: 0px 0px 0px 5px; width: 300px; vertical-align: top;color: #777777">{{$details['Title']}}</td>
                                                            </tr>
                                                            <tr>
                                                                <td style="padding: 0px 5px 0px 0px; width: 250px; vertical-align: top;color: #777777">Status</td>
                                                                <td style="padding: 0px 0px 0px 5px; width: 300px; vertical-align: top;color: #777777">{{$details['Status']}}</td>
                                                            </tr>
                                                            <tr>
                                                                <td style="padding: 0px 5px 0px 0px; width: 250px; vertical-align: top;color: #777777">Service type</td>
                                                                <td style="padding: 0px 0px 0px 5px; width: 300px; vertical-align: top;color: #777777">{{$details['ServiceType']}}</td>
                                                            </tr>
                                                            <tr>
                                                                <td style="padding: 0px 5px 0px 0px; width: 250px; vertical-align: top;color: #777777">Transfer type</td>
                                                                <td style="padding: 0px 0px 0px 5px; width: 300px; vertical-align: top;color: #777777">{{$details['TransferType']}}</td>
                                                            </tr>
                                                            <tr>
                                                                <td style="padding: 0px 5px 0px 0px; width: 250px; vertical-align: top;color: #777777">Pickup date and time</td>
                                                                <td style="padding: 0px 0px 0px 5px; width: 300px; vertical-align: top;color: #777777">{{$details['pickupDateTime']}}</td>
                                                            </tr>
                                                            <tr>
                                                                <td style="padding: 0px 5px 0px 0px; width: 250px; vertical-align: top;color: #777777">Order total amount</td>
                                                                <td style="padding: 0px 0px 0px 5px; width: 300px; vertical-align: top;color: #777777">{{$details['OrderTotalAmount']}}</td>
                                                            </tr>
                                                            {{--  <tr>
                                                                <td style="padding: 0px 5px 0px 0px; width: 250px; vertical-align: top;color: #777777">Taxes</td>
                                                                <td style="padding: 0px 0px 0px 5px; width: 300px; vertical-align: top;color: #777777">{{$details['Taxes']}}</td>
                                                            </tr>  --}}
                                                            <tr>
                                                                <td style="padding: 0px 5px 0px 0px; width: 250px; vertical-align: top;color: #777777">To pay (deposit 100%)</td>
                                                                <td style="padding: 0px 0px 0px 5px; width: 300px; vertical-align: top;color: #777777">{{$details['toPay']}}</td>
                                                            </tr>
                                                            <tr>
                                                                <td style="padding: 0px 5px 0px 0px; width: 250px; vertical-align: top;color: #777777">Distance</td>
                                                                <td style="padding: 0px 0px 0px 5px; width: 300px; vertical-align: top;color: #777777">
                                                                    {{$details['Distance']}}
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td style="padding: 0px 5px 0px 0px; width: 250px; vertical-align: top;color: #777777">Duration</td>
                                                                <td style="padding: 0px 0px 0px 5px; width: 300px; vertical-align: top;color: #777777">
                                                                    {{$details['Duration']}}
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td style="padding: 0px 5px 0px 0px; width: 250px; vertical-align: top;color: #777777">Comment</td>
                                                                <td style="padding: 0px 0px 0px 5px; width: 300px; vertical-align: top;color: #777777">{{$details['Comment']}}</td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td style="padding: 0px; height: 30px;"></td>
                                            </tr>
                                            <tr>
                                                <td style="padding: 0px 0px 5px 0px; font-weight: bold; color: #444444; border-bottom: dotted 1px #aaaaaa; text-transform: uppercase;font-family: Arial;">Route locations</td>
                                            </tr>
                                            <tr>
                                                <td style="padding: 0px; height: 15px;"></td>
                                            </tr>
                                            <tr>
                                                <td style="padding: 0px;">
                                                    <table cellspacing="0" cellpadding="0">
                                                        <tbody>
                                                            <tr>
                                                                <td style="padding: 0px;">
                                                                    <ol style="margin: 0px; padding: 0px; list-style-position: inside;">
                                                                        @if($details['count_route'] == 1)
                                                                        <?php
                                                                        $routeLocation = json_decode($details['routeLocations']);
                                                                        $count_routeLocation = count(json_decode($details['routeLocations']));
                                                                        $number = 1
                                                                        ?>
                                                                        @for ($i = 0; $i < $count_routeLocation; $i++)
                                                                        <ol style="margin: 0px; padding: 0px; color: #777777">

                                                                          <span>{{ $number++ }}</span>. {{ $routeLocation[$i] }}

                                                                        </ol>
                                                                        @endfor
                                                                        @endif


                                                                    </ol>
                                                                </td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td style="padding: 0px; height: 30px;"></td>
                                            </tr>
                                            <tr>
                                                <td style="padding: 0px 0px 5px 0px; font-weight: bold; color: #444444; border-bottom: dotted 1px #aaaaaa; text-transform: uppercase;font-family: Arial;">Returns</td>
                                            </tr>
                                            <tr>
                                                <td style="padding: 0px; height: 15px;"></td>
                                            </tr>
                                            <tr>
                                                <td style="padding: 0px;">
                                                    <table cellspacing="0" cellpadding="0">
                                                        <tbody>
                                                            <tr>
                                                                <td style="padding: 0px;">
                                                                    <ol style="margin: 0px; padding: 0px; list-style-position: inside;">
                                                                        @if($details['count'] == 1)


                                                                        <?php
                                                                        $return = json_decode($details['return']);
                                                                        $count_return = count(json_decode($details['return']));
                                                                        $number = 1
                                                                        ?>
                                                                        @for ($i = 0; $i < $count_return; $i++)
                                                                        <ol style="margin: 0px; padding: 0px; color: #777777">

                                                                          <span>{{ $number++ }}</span>. {{ $return[$i] }}

                                                                        </ol>
                                                                        @endfor
                                                                        @endif


                                                                    </ol>
                                                                </td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td style="padding: 0px; height: 30px;"></td>
                                            </tr>
                                            <tr>
                                                <td style="padding: 0px 0px 5px 0px; font-weight: bold; color: #444444; border-bottom: dotted 1px #aaaaaa; text-transform: uppercase;font-family: Arial;">Vehicle</td>
                                            </tr>
                                            <tr>
                                                <td style="padding: 0px; height: 15px;"></td>
                                            </tr>
                                            <tr>
                                                <td style="padding: 0px;">
                                                    <table cellspacing="0" cellpadding="0">
                                                        <tbody>
                                                            <tr>
                                                                <td style="padding: 0px 5px 0px 0px; width: 250px; vertical-align: top;color: #777777">Vehicle name</td>
                                                                <td style="padding: 0px 0px 0px 5px; width: 300px; vertical-align: top;color: #777777">{{$details['VehicleName']}}</td>
                                                            </tr>
                                                            <tr>
                                                                <td style="padding: 0px 5px 0px 0px; width: 250px; vertical-align: top;color: #777777">Bag count</td>
                                                                <td style="padding: 0px 0px 0px 5px; width: 300px; vertical-align: top;color: #777777">{{$details['BagCount']}}</td>
                                                            </tr>
                                                            <tr>
                                                                <td style="padding: 0px 5px 0px 0px; width: 250px; vertical-align: top;color: #777777">Passengers count</td>
                                                                <td style="padding: 0px 0px 0px 5px; width: 300px; vertical-align: top;color: #777777">{{$details['PassengersCount']}}</td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td style="padding: 0px; height: 30px;"></td>
                                            </tr>
                                            <tr>
                                                <td style="padding: 0px 0px 5px 0px; font-weight: bold; color: #444444; border-bottom: dotted 1px #aaaaaa; text-transform: uppercase;font-family: Arial;">Extras</td>
                                            </tr>
                                            <tr>
                                                <td style="padding: 0px; height: 15px;"></td>
                                            </tr>
                                            <tr>
                                                <td style="padding: 0px;">
                                                    <table cellspacing="0" cellpadding="0">
                                                        <tbody>
                                                            <tr>
                                                                <td style="padding: 0px;">
                                                                    <ol style="margin: 0px; padding: 0px; list-style-position: inside;">
                                                                        @if($details['extras_count'] == 1)


                                                                        <?php
                                                                        $extras = json_decode($details['extras']);
                                                                        $count_extras = count(json_decode($details['extras']));
                                                                        $number = 1
                                                                        ?>
                                                                        @if($count_extras == 1)
                                                                        @for ($i = 0; $i < $count_extras; $i++)
                                                                        <ol style="margin: 0px; padding: 0px; color: #777777">

                                                                          {{ $extras[$i] }}

                                                                        </ol>
                                                                        @endfor
                                                                            @else
                                                                            @for ($i = 0; $i < $count_extras; $i++)
                                                                            <ol style="margin: 0px; padding: 0px; color: #777777">

                                                                              <span>{{ $number++ }}</span>. {{ $extras[$i] }}

                                                                            </ol>
                                                                            @endfor

                                                                        @endif

                                                                        @endif


                                                                    </ol>
                                                                </td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </td>
                                            </tr>
                                            <tr>
                                            <tr>
                                                <td style="padding: 0px; height: 30px;"></td>
                                            </tr>
                                            <tr>
                                                <td style="padding: 0px 0px 5px 0px; font-weight: bold; color: #444444; border-bottom: dotted 1px #aaaaaa; text-transform: uppercase;font-family: Arial;">Client details</td>
                                            </tr>
                                            <tr>
                                                <td style="padding: 0px; height: 15px;"></td>
                                            </tr>
                                            <tr>
                                                <td style="padding: 0px;">
                                                    <table cellspacing="0" cellpadding="0">
                                                        <tbody>
                                                            <tr>
                                                                <td style="padding: 0px 5px 0px 0px; width: 250px; vertical-align: top; color: #777777">First name</td>
                                                                <td style="padding: 0px 0px 0px 5px; width: 300px; vertical-align: top; color: #777777">{{$details['FirstName']}}</td>
                                                            </tr>
                                                            <tr>
                                                                <td style="padding: 0px 5px 0px 0px; width: 250px; vertical-align: top; color: #777777">Last name</td>
                                                                <td style="padding: 0px 0px 0px 5px; width: 300px; vertical-align: top; color: #777777">{{$details['LastName']}}</td>
                                                            </tr>
                                                            <tr>
                                                                <td style="padding: 0px 5px 0px 0px; width: 250px; vertical-align: top; color: #777777">E-mail address</td>
                                                                <td style="padding: 0px 0px 0px 5px; width: 300px; vertical-align: top; color: #777777"><a href="mailto:example@example.com" target="_blank">{{$details['EmailAddress']}}</a></td>
                                                            </tr>
                                                            <tr>
                                                                <td style="padding: 0px 5px 0px 0px; width: 250px; vertical-align: top; color: #777777">Phone number</td>
                                                                <td style="padding: 0px 0px 0px 5px; width: 300px; vertical-align: top; color: #777777">{{$details['PhoneNumber']}}</td>
                                                            </tr>
                                                            <tr>
                                                                <td style="padding: 0px 5px 0px 0px; width: 250px; vertical-align: top; color: #777777">Flight Details</td>
                                                                <td style="padding: 0px 0px 0px 5px; width: 300px; vertical-align: top; color: #777777">{{$details['FlightDetails']}}</td>
                                                            </tr>
                                                            <tr>
                                                                <td style="padding: 0px 5px 0px 0px; width: 250px; vertical-align: top; color: #777777">Name Board</td>
                                                                <td style="padding: 0px 0px 0px 5px; width: 300px; vertical-align: top; color: #777777">{{$details['NameBoard']}} </td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td style="padding: 0px; height: 30px;"></td>
                                            </tr>
                                            <tr>
                                                <td style="padding: 0px 0px 5px 0px; font-weight: bold; color: #444444; border-bottom: dotted 1px #aaaaaa; text-transform: uppercase;font-family: Arial;">Payment</td>
                                            </tr>
                                            <tr>
                                                <td style="padding: 0px; height: 15px;"></td>
                                            </tr>
                                            <tr>
                                                <td style="padding: 0px;">
                                                    <table cellspacing="0" cellpadding="0">
                                                        <tbody>
                                                            <tr>
                                                                <td style="padding: 0px 5px 0px 0px; width: 250px; vertical-align: top; color: #777777;">Payment</td>
                                                                <td style="padding: 0px 0px 0px 5px; width: 300px; vertical-align: top;color: #777777">
                                                                    Pending
                                                                </td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </td>
                            </tr>
                            <tr>
                                <td style="padding-left:50px;padding-right:50px;">

                                    <table style="font-family:'Montserrat',sans-serif" cellpadding="0" cellspacing="0" width="100%" border="0">
                                        <tbody>
                                            <tr>
                                                <td style="word-break:break-word;padding:0px;font-family:'Montserrat',sans-serif" align="left">
                                                    <div style="line-height:140%;text-align:left;word-wrap:break-word">
                                                        <p style="font-size: 14px; line-height: 140%; text-align: left;color: #777777;">
                                                            If any of the above information is incorrect or you need to modify any details, please contact us at <strong>+44 203 9300286</strong>. for more information visit our website
                                                            <span style="font-size: 14px; line-height: 19.6px;">
                                                                <strong>
                                                                    <span style="color: #000000; font-size: 14px; line-height: 19.6px;"><a  href="https://epicridelondon.com/" style="color: #000000;text-transform: capitalize;" target="_blank">epic ride london.</a></span>
                                                                </strong>
                                                            </span>
                                                            <br />
                                                            &nbsp;<br />
                                                            Warm Regards,<br />
                                                            Team Epic Ride.
                                                        </p>
                                                    </div>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </td>
                            </tr>
                            <tr>
                                <td style="padding: 30px 30px;
                                    background-image: url(https://res.cloudinary.com/dyidzfrja/image/upload/v1680435969/personal/london_mtl9u1.png);
                                    background-position: bottom;
                                    background-repeat: no-repeat;
                                    background-size: contain" bgcolor=" #C99B20">
                                    <table style="" role="presentation" cellpadding="0" cellspacing="0" width="100%" border="0">
                                        <tbody>
                                            <tr>
                                                <td style="word-break: break-word; padding: 0px 0px; " align="left">
                                                    <div style="color: #fff; line-height: 140%; text-align: center; word-wrap: break-word;">
                                                        <p style="font-size: 14px; line-height: 140%;">
                                                            <strong><span style="font-size: 18px; line-height: 25.2px;">EPIC RIDE LONDON.</span></strong>
                                                        </p>
                                                    </div>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>

                                    <table style="" role="presentation" cellpadding="0" cellspacing="0" width="100%" border="0">
                                        <tbody>
                                            <tr>
                                                <td style="word-break: break-word; padding: 0px 10px 0 10px; " align="left">
                                                    <div style="color: #fff; line-height: 180%; text-align: center; word-wrap: break-word;">
                                                        <p style="font-size: 14px; line-height: 180%;">
                                                        450 Bath Rd, Longford, Heathrow, UK. UB7 0EB</p>
                                                        <p style="font-size: 14px; line-height: 180%;">+44 203 9300286</p>
                                                    </div>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                    <table style="" role="presentation" cellpadding="0" cellspacing="0" width="100%" border="0">
                                        <tbody>
                                            <tr>
                                                <td style="word-break: break-word; padding: 10px; " align="left">
                                                    <div align="center">
                                                        <div style="display: table; max-width: 211px;">
                                                            <table align="left" border="0" cellspacing="0" cellpadding="0" width="32" height="32" style="border-collapse: collapse; table-layout: fixed; border-spacing: 0; vertical-align: top; margin-right: 21px;">
                                                                <tbody>
                                                                    <tr style="vertical-align: top;">
                                                                        <td align="left" valign="middle" style="word-break: break-word; border-collapse: collapse !important; vertical-align: top;">
                                                                            <a
                                                                                href=""
                                                                                title="Facebook"
                                                                                target="_blank"
                                                                            >
                                                                                <img
                                                                                src="https://res.cloudinary.com/dyidzfrja/image/upload/v1680382500/personal/fb_t8p2fo.png"
                                                                                    alt="Facebook"
                                                                                    title="Facebook"
                                                                                    width="32"
                                                                                    style="outline: none; text-decoration: none; clear: both; display: block !important; border: none; height: auto; float: none; max-width: 32px !important;"
                                                                                    class="CToWUd"
                                                                                    data-bit="iit"
                                                                                />
                                                                            </a>
                                                                        </td>
                                                                    </tr>
                                                                </tbody>
                                                            </table>

                                                            <table align="left" border="0" cellspacing="0" cellpadding="0" width="32" height="32" style="border-collapse: collapse; table-layout: fixed; border-spacing: 0; vertical-align: top; margin-right: 21px;">
                                                                <tbody>
                                                                    <tr style="vertical-align: top;">
                                                                        <td align="left" valign="middle" style="word-break: break-word; border-collapse: collapse !important; vertical-align: top;">
                                                                            <a
                                                                                href=""
                                                                                title="Instagram"
                                                                                target="_blank"
                                                                            >
                                                                                <img
                                                                                src="https://res.cloudinary.com/dyidzfrja/image/upload/v1680382541/personal/inst_mf8kyt.png"
                                                                                    alt="Instagram"
                                                                                    title="Instagram"
                                                                                    width="32"
                                                                                    style="outline: none; text-decoration: none; clear: both; display: block !important; border: none; height: auto; float: none; max-width: 32px !important;"
                                                                                    class="CToWUd"
                                                                                    data-bit="iit"
                                                                                />
                                                                            </a>
                                                                        </td>
                                                                    </tr>
                                                                </tbody>
                                                            </table>

                                                            <table align="left" border="0" cellspacing="0" cellpadding="0" width="32" height="32" style="border-collapse: collapse; table-layout: fixed; border-spacing: 0; vertical-align: top; margin-right: 21px;">
                                                                <tbody>
                                                                    <tr style="vertical-align: top;">
                                                                        <td align="left" valign="middle" style="word-break: break-word; border-collapse: collapse !important; vertical-align: top;">
                                                                            <a
                                                                                href=""
                                                                                title="Youtube"
                                                                                target="_blank"
                                                                            >
                                                                                <img
                                                                                    src="https://res.cloudinary.com/dyidzfrja/image/upload/v1680435650/personal/youtube_l7sjo4.png"
                                                                                    alt="Youtube"
                                                                                    title="Youtube"
                                                                                    width="32"
                                                                                    style="outline: none; text-decoration: none; clear: both; display: block !important; border: none; height: auto; float: none; max-width: 32px !important;"
                                                                                    class="CToWUd"
                                                                                    data-bit="iit"
                                                                                />
                                                                            </a>
                                                                        </td>
                                                                    </tr>
                                                                </tbody>
                                                            </table>

                                                            <table align="left" border="0" cellspacing="0" cellpadding="0" width="32" height="32" style="border-collapse: collapse; table-layout: fixed; border-spacing: 0; vertical-align: top; margin-right: 0px;">
                                                                <tbody>
                                                                    <tr style="vertical-align: top;">
                                                                        <td align="left" valign="middle" style="word-break: break-word; border-collapse: collapse !important; vertical-align: top;">
                                                                            <a
                                                                                href=""
                                                                                title="Twitter"
                                                                                target="_blank"
                                                                            >
                                                                                <img
                                                                                    src="https://res.cloudinary.com/dyidzfrja/image/upload/v1680382589/personal/twitter_fiog9p.png"
                                                                                    alt="Twitter"
                                                                                    title="Twitter"
                                                                                    width="32"
                                                                                    style="outline: none; text-decoration: none; clear: both; display: block !important; border: none; height: auto; float: none; max-width: 32px !important;"
                                                                                    class="CToWUd"
                                                                                    data-bit="iit"
                                                                                />
                                                                            </a>
                                                                        </td>
                                                                    </tr>
                                                                </tbody>
                                                            </table>
                                                        </div>
                                                    </div>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>

                                    <table style="" role="presentation" cellpadding="0" cellspacing="0" width="100%" border="0">
                                        <tbody>
                                            <tr>
                                                <td style="word-break: break-word; padding: 10px; " align="left">
                                                    <table
                                                        height="0px"
                                                        align="center"
                                                        border="0"
                                                        cellpadding="0"
                                                        cellspacing="0"
                                                        width="82%"
                                                        style="border-collapse: collapse; table-layout: fixed; border-spacing: 0; vertical-align: top; border-top: 1px solid #fff;"
                                                    >
                                                        <tbody>
                                                            <tr style="vertical-align: top;">
                                                                <td style="word-break: break-word; border-collapse: collapse !important; vertical-align: top; font-size: 0px; line-height: 0px;">
                                                                    <span>&nbsp;</span>
                                                                </td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>

                                    <table style="" role="presentation" cellpadding="0" cellspacing="0" width="100%" border="0">
                                        <tbody>
                                            <tr>
                                                <td style="word-break: break-word; padding: 10px; " align="left">
                                                    <div style="text-align: center;">
                                                        <a
                                                            href="https://epicridelondon.com/services"
                                                            style="padding: 5px 15px; display: inline-block; color: #fff;  font-size: 14px; text-decoration: none;"
                                                            target="_blank"
                                                        >
                                                            Services
                                                        </a>

                                                        <a
                                                            href="https://epicridelondon.com/fleets"
                                                            style="padding: 5px 15px; display: inline-block; color: #fff;  font-size: 14px; text-decoration: none;"
                                                            target="_blank"
                                                        >
                                                            Our Fleets
                                                        </a>

                                                        <a
                                                            href="https://epicridelondon.com/about-us"
                                                            style="padding: 5px 15px; display: inline-block; color: #fff;  font-size: 14px; text-decoration: none;"
                                                            target="_blank"
                                                        >
                                                            About Us
                                                        </a>

                                                        <a
                                                            href="https://epicridelondon.com/terms-&-conditions"
                                                            style="padding: 5px 15px; display: inline-block; color: #fff;  font-size: 14px; text-decoration: none;"
                                                            target="_blank"
                                                        >
                                                            Terms &amp; Conditions
                                                        </a>
                                                    </div>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>

                                    <table style="" role="presentation" cellpadding="0" cellspacing="0" width="100%" border="0">
                                        <tbody>
                                            <tr>
                                                <td style="word-break: break-word; padding: 10px; " align="left">
                                                    <table
                                                        height="0px"
                                                        align="center"
                                                        border="0"
                                                        cellpadding="0"
                                                        cellspacing="0"
                                                        width="82%"
                                                        style="border-collapse: collapse; table-layout: fixed; border-spacing: 0; vertical-align: top; border-top: 1px solid #fff;"
                                                    >
                                                        <tbody>
                                                            <tr style="vertical-align: top;">
                                                                <td style="word-break: break-word; border-collapse: collapse !important; vertical-align: top; font-size: 0px; line-height: 0px;">
                                                                    <span>&nbsp;</span>
                                                                </td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>

                                    <table style="" role="presentation" cellpadding="0" cellspacing="0" width="100%" border="0">
                                        <tbody>
                                            <tr>
                                                <td style="word-break: break-word; padding: 0px 10px 13px; " align="left">
                                                    <div style="color: #fff; line-height: 180%; text-align: center; word-wrap: break-word;">
                                                        <p style="font-size: 14px; line-height: 180%;font-weight: bold;">© 2023 All Rights Reserved</p>
                                                    </div>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </td>
                            </tr>


                        </table>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</body>

</html>
