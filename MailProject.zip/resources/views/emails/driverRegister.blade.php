<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Driver Register Email Template || Epic Chauffeur</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;1,300;1,400;1,500;1,600;1,700;1,800&family=Rajdhani:wght@300;400;500;600;700&display=swap"
        rel="stylesheet">
    <style type="text/css">
        body {
            font-family: 'Rajdhani', sans-serif !important;
        }

        .color-text {
            color: #143E8F;
        }

        .mar-0 {
            margin: 0px;
        }

        .btncss-d {
            border: 1px solid #d9d9d9;
            padding: 8px 20px;
            border-radius: 5px;
            display: flex;
            align-items: center;
            font-size: 12px;
            background-color: transparent;
            box-shadow: 0 2px 0 rgba(0, 0, 0, 0.015);
        }

        .btncss-d:hover {
            border-color: #c99b20;
        }
    </style>
</head>

<body style="padding: 0px;margin: 0px;">
    <div style="max-width:100%,width: 100%;padding: 0px;">
        <table style="width: 100%;">
            <tbody>
                <tr>
                    <td>
                        <table
                            style="width:700px;border: 1px solid gray;margin-left: auto;margin-right: auto;padding: 0px;border-spacing: 0px;">
                            <tr>
                                <td style="padding: 0px;">
                                    <div
                                        style="background-image:url(https://res.cloudinary.com/dyidzfrja/image/upload/v1680435519/personal/headimg_j9ctix.jpg);text-align: center;    background-repeat: no-repeat;background-position: center;height: 40vh;background-size: cover;">
                                        <img src="https://res.cloudinary.com/dyidzfrja/image/upload/v1680436034/personal/logo_kmzx1h.png"
                                            style="width: 40%; transform: translateY(-10px);">
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td style="padding:50px;padding-top: 30px;padding-bottom: 20px;">
                                    <table>
                                        <tbody>
                                            <tr>
                                                <td class="color-text"
                                                    style="font-weight: bold; border-bottom: dotted 1px #aaaaaa; text-transform: uppercase;">
                                                    <h3 class="mar-0">Personal Info</h3>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td style="padding: 0px; height: 15px;"></td>
                                            </tr>
                                            <tr>
                                                <td style="padding: 0px;">
                                                    <table cellspacing="0" cellpadding="0">
                                                        <tbody>
                                                            <tr>
                                                                <td style="padding-bottom: 10px;">
                                                                    <div
                                                                        style="width:80px;height: 80px;border: 1px solid gray;padding: 3px;">
                                                                        <img src="{{ $details['profilePhoto'] }}"
                                                                            style="max-width:100%;">
                                                                    </div>
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td
                                                                    style="padding: 0px 5px 0px 0px; width: 250px; vertical-align: top;color: #777777">
                                                                    Fullname</td>
                                                                <td
                                                                    style="padding: 0px 0px 0px 5px; width: 300px; vertical-align: top;color: #777777">
                                                                    {{ $details['fullName'] }}</td>
                                                            </tr>
                                                            <tr>
                                                                <td
                                                                    style="padding: 0px 5px 0px 0px; width: 250px; vertical-align: top;color: #777777">
                                                                    Email</td>
                                                                <td
                                                                    style="padding: 0px 0px 0px 5px; width: 300px; vertical-align: top;color: #777777">
                                                                    {{ $details['email'] }}</td>
                                                            </tr>
                                                            <tr>
                                                                <td
                                                                    style="padding: 0px 5px 0px 0px; width: 250px; vertical-align: top;color: #777777">
                                                                    Phone</td>
                                                                <td
                                                                    style="padding: 0px 0px 0px 5px; width: 300px; vertical-align: top;color: #777777">
                                                                    {{ $details['phone'] }}</td>
                                                            </tr>
                                                            <tr>
                                                                <td
                                                                    style="padding: 0px 5px 0px 0px; width: 250px; vertical-align: top;color: #777777">
                                                                    NI Number</td>
                                                                <td
                                                                    style="padding: 0px 0px 0px 5px; width: 300px; vertical-align: top;color: #777777">
                                                                    {{ $details['NiNumber'] }} </td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </td>
                            </tr>
                            <tr>
                                <td style="padding:50px;padding-top: 10px;">
                                    <table cellspacing="0" cellpadding="0" width="100%">
                                        <tbody>
                                            <tr>
                                                <td class="color-text"
                                                    style="font-weight: bold; border-bottom: dotted 1px #aaaaaa; text-transform: uppercase;">
                                                    <h3 class="mar-0">Address</h3>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td style="padding: 0px; height: 15px;"></td>
                                            </tr>
                                            <tr>
                                                <td style="padding: 0px;">
                                                    <table cellspacing="0" cellpadding="0">
                                                        <tbody>
                                                            <tr>
                                                                <td
                                                                    style="padding: 0px 5px 0px 0px; width: 250px; vertical-align: top;color: #777777">
                                                                    Street Address</td>
                                                                <td
                                                                    style="padding: 0px 0px 0px 5px; width: 300px; vertical-align: top;color: #777777">
                                                                    {{ $details['StreetAddress'] }}</td>
                                                            </tr>
                                                            <tr>
                                                                <td
                                                                    style="padding: 0px 5px 0px 0px; width: 250px; vertical-align: top;color: #777777">
                                                                    Address Line 2</td>
                                                                <td
                                                                    style="padding: 0px 0px 0px 5px; width: 300px; vertical-align: top;color: #777777">
                                                                    {{ $details['addressLinetwo'] }}</td>
                                                            </tr>
                                                            <tr>
                                                                <td
                                                                    style="padding: 0px 5px 0px 0px; width: 250px; vertical-align: top;color: #777777">
                                                                    City</td>
                                                                <td
                                                                    style="padding: 0px 0px 0px 5px; width: 300px; vertical-align: top;color: #777777">
                                                                    {{ $details['city'] }}</td>
                                                            </tr>

                                                            <tr>
                                                                <td
                                                                    style="padding: 0px 5px 0px 0px; width: 250px; vertical-align: top;color: #777777">
                                                                    State / Province / Region
                                                                </td>
                                                                <td
                                                                    style="padding: 0px 0px 0px 5px; width: 300px; vertical-align: top;color: #777777">
                                                                    {{ $details['state'] }}
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td
                                                                    style="padding: 0px 5px 0px 0px; width: 250px; vertical-align: top;color: #777777">
                                                                    ZIP / Postal Code
                                                                </td>
                                                                <td
                                                                    style="padding: 0px 0px 0px 5px; width: 300px; vertical-align: top;color: #777777">
                                                                    {{ $details['postalCode'] }}
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td
                                                                    style="padding: 0px 5px 0px 0px; width: 250px; vertical-align: top;color: #777777">
                                                                    Country</td>
                                                                <td
                                                                    style="padding: 0px 0px 0px 5px; width: 300px; vertical-align: top;color: #777777">
                                                                    {{ $details['country'] }}</td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td style="padding: 0px; height: 30px;"></td>
                                            </tr>
                                            <tr>
                                                <td class="color-text"
                                                    style="font-weight: bold; border-bottom: dotted 1px #aaaaaa; text-transform: uppercase;">
                                                    <h3 class="mar-0">Bank Details</h3>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td style="padding: 0px; height: 15px;"></td>
                                            </tr>
                                            <tr>
                                                <td style="padding: 0px;">
                                                    <table cellspacing="0" cellpadding="0">
                                                        <tbody>
                                                            <tr>
                                                                <td
                                                                    style="padding: 0px 5px 0px 0px; width: 250px; vertical-align: top;color: #777777">
                                                                    Sort Code</td>
                                                                <td
                                                                    style="padding: 0px 0px 0px 5px; width: 300px; vertical-align: top;color: #777777">
                                                                    {{ $details['sortCode'] }}</td>
                                                            </tr>
                                                            <tr>
                                                                <td
                                                                    style="padding: 0px 5px 0px 0px; width: 250px; vertical-align: top;color: #777777">
                                                                    Account Number</td>
                                                                <td
                                                                    style="padding: 0px 0px 0px 5px; width: 300px; vertical-align: top;color: #777777">
                                                                    {{ $details['accountNumber'] }}
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td
                                                                    style="padding: 0px 5px 0px 0px; width: 250px; vertical-align: top;color: #777777">
                                                                    Comment</td>
                                                                <td
                                                                    style="padding: 0px 0px 0px 5px; width: 300px; vertical-align: top;color: #777777">
                                                                    {{ $details['comment'] }}
                                                                </td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </td>

                                            </tr>

                                            <tr>
                                                <td style="padding: 0px; height: 30px;"></td>
                                            </tr>
                                            <tr>
                                                <td class="color-text"
                                                    style="font-weight: bold; border-bottom: dotted 1px #aaaaaa; text-transform: uppercase;">
                                                    <h3 class="mar-0">Documents</h3>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td style="padding: 0px; height: 15px;"></td>
                                            </tr>
                                            <tr>
                                                <td style="padding: 0px;">
                                                    <table cellspacing="10">
                                                        <tbody>
                                                            <tr>
                                                                <td>
                                                                    <p style="margin:0px;white-space: nowrap;">Pictures
                                                                        of cars</p>
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <?php
                                                                $carPicture = json_decode($details['carPicture']);
                                                                $count_car_picture = count(json_decode($details['carPicture']));
                                                                ?>
                                                                @for ($i = 0; $i < $count_car_picture; $i++)
                                                                    <td style="padding-bottom: 10px;">
                                                                        <div
                                                                            style="width:80px;height: 80px;border: 1px solid gray;padding: 3px;">
                                                                            <img src="{{ $carPicture[$i] }}"
                                                                                style="max-width:100%;">
                                                                        </div>
                                                                    </td>
                                                                @endfor
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                    <table cellspacing="10" cellpadding="0"
                                                        style="vertical-align: middle;order-bottom: dotted 1px #aaaaaa;">
                                                        <tbody>
                                                            <tr>
                                                                <td
                                                                    style="padding: 0px 5px 0px 0px; width: 250px; vertical-align: top;color: #777777">
                                                                    Driver PCO license
                                                                </td>
                                                                <td
                                                                    style="padding: 0px 0px 0px 5px; width: 300px; vertical-align: top;color: #777777">
                                                                    <a href="{{ $details['driverPCOlicense'] }}"target="_blank"
                                                                        alt="">
                                                                        <button class="btncss-d">
                                                                            <span><img
                                                                                    src="https://res.cloudinary.com/dyidzfrja/image/upload/v1680551856/personal/upload_h9odmi.png"
                                                                                    style="padding-right: 8px;width: 12px;"></span>
                                                                            <span>Download File</span>
                                                                        </button>
                                                                    </a>

                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td
                                                                    style="padding: 0px 5px 0px 0px; width: 250px; vertical-align: top;color: #777777">
                                                                    Driver PCO badge
                                                                </td>
                                                                <td
                                                                    style="padding: 0px 0px 0px 5px; width: 300px; vertical-align: top;color: #777777">
                                                                    <a href="{{ $details['driverPCObadge'] }}"target="_blank"
                                                                        alt="">
                                                                        <button class="btncss-d">
                                                                            <span><img
                                                                                    src="https://res.cloudinary.com/dyidzfrja/image/upload/v1680551856/personal/upload_h9odmi.png"
                                                                                    style="padding-right: 8px;width: 12px;"></span>
                                                                            <span>Download File</span>
                                                                        </button>
                                                                    </a>

                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td
                                                                    style="padding: 0px 5px 0px 0px; width: 250px; vertical-align: top;color: #777777">
                                                                    Driving license (Both side)
                                                                </td>
                                                                <td
                                                                    style="padding: 0px 0px 0px 5px; width: 300px; vertical-align: top;color: #777777">
                                                                    <?php
                                                                    $records = json_decode($details['drivingLicense']);
                                                                    $count = count(json_decode($details['drivingLicense']));
                                                                    ?>
                                                                    @for ($i = 0; $i < $count; $i++)
                                                                        <a  href="{{ $records[$i] }}"target="_blank"
                                                                            alt="">
                                                                            <button style = "margin-top:10px" class="btncss-d">
                                                                                <span><img
                                                                                        src="https://res.cloudinary.com/dyidzfrja/image/upload/v1680551856/personal/upload_h9odmi.png"
                                                                                        style="padding-right: 8px;width: 12px;"></span>
                                                                                <span>Download File</span>
                                                                            </button>
                                                                        </a>
                                                                    @endfor

                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td
                                                                    style="padding: 0px 5px 0px 0px; width: 250px; vertical-align: top;color: #777777">
                                                                    Car Insurance
                                                                </td>
                                                                <td
                                                                    style="padding: 0px 0px 0px 5px; width: 300px; vertical-align: top;color: #777777">
                                                                    <?php
                                                                    $carinsurance = json_decode($details['carinsurance']);
                                                                    $carinsurancecount = count(json_decode($details['carinsurance']));
                                                                    ?>
                                                                    @for ($i = 0; $i < $carinsurancecount; $i++)
                                                                        <a style = "margin-top:10px" href="{{ $carinsurance[$i] }}"target="_blank"
                                                                            alt="">
                                                                            <button style = "margin-top:10px" class="btncss-d mb-2">
                                                                                <span><img
                                                                                        src="https://res.cloudinary.com/dyidzfrja/image/upload/v1680551856/personal/upload_h9odmi.png"
                                                                                        style="padding-right: 8px;width: 12px;"></span>
                                                                                <span>Download File</span>
                                                                            </button>
                                                                        </a>
                                                                    @endfor

                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td
                                                                    style="padding: 0px 5px 0px 0px; width: 250px; vertical-align: top;color: #777777">
                                                                    Logbook
                                                                </td>
                                                                <td
                                                                    style="padding: 0px 0px 0px 5px; width: 300px; vertical-align: top;color: #777777">
                                                                    <?php
                                                                    $logBookPicture = json_decode($details['logBookPicture']);
                                                                    $log_book_picture = count(json_decode($details['logBookPicture']));
                                                                    ?>
                                                                    @for ($i = 0; $i < $log_book_picture; $i++)
                                                                        <a style = "margin-top:10px" href="{{ $logBookPicture[$i] }}"target="_blank"
                                                                            alt="">
                                                                            <button style = "margin-top:10px" class="btncss-d mb-2">
                                                                                <span><img
                                                                                        src="https://res.cloudinary.com/dyidzfrja/image/upload/v1680551856/personal/upload_h9odmi.png"
                                                                                        style="padding-right: 8px;width: 12px;"></span>
                                                                                <span>Download File</span>
                                                                            </button>
                                                                        </a>
                                                                    @endfor

                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td
                                                                    style="padding: 0px 5px 0px 0px; width: 250px; vertical-align: top;color: #777777">
                                                                    Mot Certificate
                                                                </td>
                                                                <td
                                                                    style="padding: 0px 0px 0px 5px; width: 300px; vertical-align: top;color: #777777">
                                                                    <?php
                                                                    $motCertificate = json_decode($details['carinsurance']);
                                                                    $motCertificatecount = count(json_decode($details['carinsurance']));
                                                                    ?>
                                                                    @for ($i = 0; $i < $motCertificatecount; $i++)
                                                                        <a style = "margin-top:10px" href="{{ $motCertificate[$i] }}"target="_blank"
                                                                            alt="">
                                                                            <button style = "margin-top:10px" class="btncss-d mb-2">
                                                                                <span><img
                                                                                        src="https://res.cloudinary.com/dyidzfrja/image/upload/v1680551856/personal/upload_h9odmi.png"
                                                                                        style="padding-right: 8px;width: 12px;"></span>
                                                                                <span>Download File</span>
                                                                            </button>
                                                                        </a>
                                                                    @endfor

                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td
                                                                    style="padding: 0px 5px 0px 0px; width: 250px; vertical-align: top;color: #777777">
                                                                    Vehicle PCO license
                                                                </td>
                                                                <td
                                                                    style="padding: 0px 0px 0px 5px; width: 300px; vertical-align: top;color: #777777">
                                                                    <?php
                                                                    $carinsurance = json_decode($details['carinsurance']);
                                                                    $carinsurancecount = count(json_decode($details['carinsurance']));
                                                                    ?>
                                                                    @for ($i = 0; $i < $carinsurancecount; $i++)
                                                                        <a style = "margin-top:10px" href="{{ $carinsurance[$i] }}"target="_blank"
                                                                            alt="">
                                                                            <button style = "margin-top:10px" class="btncss-d mb-2">
                                                                                <span><img
                                                                                        src="https://res.cloudinary.com/dyidzfrja/image/upload/v1680551856/personal/upload_h9odmi.png"
                                                                                        style="padding-right: 8px;width: 12px;"></span>
                                                                                <span>Download File</span>
                                                                            </button>
                                                                        </a>
                                                                    @endfor

                                                                </td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </td>

                                            </tr>
                                        </tbody>
                                    </table>
                                </td>
                            </tr>
                            <tr>
                                <td style="padding-left:50px;padding-right:50px;">

                                    <table cellpadding="0" cellspacing="0" width="100%" border="0">
                                        <tbody>
                                            <tr>
                                                <td style="word-break:break-word;padding:0px;" align="left">
                                                    <div style="line-height:140%;text-align:left;word-wrap:break-word">
                                                        <p
                                                            style="font-size: 14px; line-height: 140%; text-align: left;color: #777777;">
                                                            If any of the above information is incorrect or you need to
                                                            modify any details, please contact us at <strong>+44 203
                                                                9300286</strong>. for more information visit our website
                                                            <span style="font-size: 14px; line-height: 19.6px;">
                                                                <strong>
                                                                    <span
                                                                        style="color: #000000; font-size: 14px; line-height: 19.6px;"><a
                                                                            href="https://epicridelondon.com/"
                                                                            style="color: #000000;text-transform: capitalize;"
                                                                            target="_blank">epic ride
                                                                            london.</a></span>
                                                                </strong>
                                                            </span>
                                                            <br />
                                                            &nbsp;<br />
                                                            Warm Regards,<br />
                                                            Team Epic Ride.
                                                        </p>
                                                    </div>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </td>
                            </tr>
                            <tr>
                                <td style="padding: 30px 30px;
                    background-image: url(https://res.cloudinary.com/dyidzfrja/image/upload/v1680435969/personal/london_mtl9u1.png);
                    background-position: bottom;
                    background-repeat: no-repeat;
                    background-size: contain"
                                    bgcolor=" #C99B20">
                                    <table style="font-family: 'Montserrat', sans-serif;" role="presentation"
                                        cellpadding="0" cellspacing="0" width="100%" border="0">
                                        <tbody>
                                            <tr>
                                                <td style="word-break: break-word; padding: 0px 0px; font-family: 'Montserrat', sans-serif;"
                                                    align="left">
                                                    <div
                                                        style="color: #fff; line-height: 140%; text-align: center; word-wrap: break-word;">
                                                        <p style="font-size: 14px; line-height: 140%;">
                                                            <strong><span
                                                                    style="font-size: 18px; line-height: 25.2px;">EPIC
                                                                    RIDE LONDON.</span></strong>
                                                        </p>
                                                    </div>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>

                                    <table style="font-family: 'Montserrat', sans-serif;" role="presentation"
                                        cellpadding="0" cellspacing="0" width="100%" border="0">
                                        <tbody>
                                            <tr>
                                                <td style="word-break: break-word; padding: 0px 10px 0 10px; font-family: 'Montserrat', sans-serif;"
                                                    align="left">
                                                    <div
                                                        style="color: #fff; line-height: 180%; text-align: center; word-wrap: break-word;">
                                                        <p style="font-size: 14px; line-height: 180%;">
                                                            450 Bath Rd, Longford, Heathrow, UK. UB7 0EB</p>
                                                        <p style="font-size: 14px; line-height: 180%;">+44 203 9300286
                                                        </p>
                                                    </div>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                    <table style="font-family: 'Montserrat', sans-serif;" role="presentation"
                                        cellpadding="0" cellspacing="0" width="100%" border="0">
                                        <tbody>
                                            <tr>
                                                <td style="word-break: break-word; padding: 10px; font-family: 'Montserrat', sans-serif;"
                                                    align="left">
                                                    <div align="center">
                                                        <div style="display: table; max-width: 211px;">
                                                            <table align="left" border="0" cellspacing="0"
                                                                cellpadding="0" width="32" height="32"
                                                                style="border-collapse: collapse; table-layout: fixed; border-spacing: 0; vertical-align: top; margin-right: 21px;">
                                                                <tbody>
                                                                    <tr style="vertical-align: top;">
                                                                        <td align="left" valign="middle"
                                                                            style="word-break: break-word; border-collapse: collapse !important; vertical-align: top;">
                                                                            <a href="" title="Facebook"
                                                                                target="_blank">
                                                                                <img src="https://res.cloudinary.com/dyidzfrja/image/upload/v1680382500/personal/fb_t8p2fo.png"
                                                                                    alt="Facebook" title="Facebook"
                                                                                    width="32"
                                                                                    style="outline: none; text-decoration: none; clear: both; display: block !important; border: none; height: auto; float: none; max-width: 32px !important;"
                                                                                    class="CToWUd" data-bit="iit" />
                                                                            </a>
                                                                        </td>
                                                                    </tr>
                                                                </tbody>
                                                            </table>

                                                            <table align="left" border="0" cellspacing="0"
                                                                cellpadding="0" width="32" height="32"
                                                                style="border-collapse: collapse; table-layout: fixed; border-spacing: 0; vertical-align: top; margin-right: 21px;">
                                                                <tbody>
                                                                    <tr style="vertical-align: top;">
                                                                        <td align="left" valign="middle"
                                                                            style="word-break: break-word; border-collapse: collapse !important; vertical-align: top;">
                                                                            <a href="" title="Instagram"
                                                                                target="_blank">
                                                                                <img src="https://res.cloudinary.com/dyidzfrja/image/upload/v1680382541/personal/inst_mf8kyt.png"
                                                                                    alt="Instagram" title="Instagram"
                                                                                    width="32"
                                                                                    style="outline: none; text-decoration: none; clear: both; display: block !important; border: none; height: auto; float: none; max-width: 32px !important;"
                                                                                    class="CToWUd" data-bit="iit" />
                                                                            </a>
                                                                        </td>
                                                                    </tr>
                                                                </tbody>
                                                            </table>

                                                            <table align="left" border="0" cellspacing="0"
                                                                cellpadding="0" width="32" height="32"
                                                                style="border-collapse: collapse; table-layout: fixed; border-spacing: 0; vertical-align: top; margin-right: 21px;">
                                                                <tbody>
                                                                    <tr style="vertical-align: top;">
                                                                        <td align="left" valign="middle"
                                                                            style="word-break: break-word; border-collapse: collapse !important; vertical-align: top;">
                                                                            <a href="" title="Youtube"
                                                                                target="_blank">
                                                                                <img src="https://res.cloudinary.com/dyidzfrja/image/upload/v1680435650/personal/youtube_l7sjo4.png"
                                                                                    alt="Youtube" title="Youtube"
                                                                                    width="32"
                                                                                    style="outline: none; text-decoration: none; clear: both; display: block !important; border: none; height: auto; float: none; max-width: 32px !important;"
                                                                                    class="CToWUd" data-bit="iit" />
                                                                            </a>
                                                                        </td>
                                                                    </tr>
                                                                </tbody>
                                                            </table>

                                                            <table align="left" border="0" cellspacing="0"
                                                                cellpadding="0" width="32" height="32"
                                                                style="border-collapse: collapse; table-layout: fixed; border-spacing: 0; vertical-align: top; margin-right: 0px;">
                                                                <tbody>
                                                                    <tr style="vertical-align: top;">
                                                                        <td align="left" valign="middle"
                                                                            style="word-break: break-word; border-collapse: collapse !important; vertical-align: top;">
                                                                            <a href="" title="Twitter"
                                                                                target="_blank">
                                                                                <img src="https://res.cloudinary.com/dyidzfrja/image/upload/v1680382589/personal/twitter_fiog9p.png"
                                                                                    alt="Twitter" title="Twitter"
                                                                                    width="32"
                                                                                    style="outline: none; text-decoration: none; clear: both; display: block !important; border: none; height: auto; float: none; max-width: 32px !important;"
                                                                                    class="CToWUd" data-bit="iit" />
                                                                            </a>
                                                                        </td>
                                                                    </tr>
                                                                </tbody>
                                                            </table>
                                                        </div>
                                                    </div>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>

                                    <table style="font-family: 'Montserrat', sans-serif;" role="presentation"
                                        cellpadding="0" cellspacing="0" width="100%" border="0">
                                        <tbody>
                                            <tr>
                                                <td style="word-break: break-word; padding: 10px; font-family: 'Montserrat', sans-serif;"
                                                    align="left">
                                                    <table height="0px" align="center" border="0"
                                                        cellpadding="0" cellspacing="0" width="82%"
                                                        style="border-collapse: collapse; table-layout: fixed; border-spacing: 0; vertical-align: top; border-top: 1px solid #fff;">
                                                        <tbody>
                                                            <tr style="vertical-align: top;">
                                                                <td
                                                                    style="word-break: break-word; border-collapse: collapse !important; vertical-align: top; font-size: 0px; line-height: 0px;">
                                                                    <span>&nbsp;</span>
                                                                </td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>

                                    <table style="font-family: 'Montserrat', sans-serif;" role="presentation"
                                        cellpadding="0" cellspacing="0" width="100%" border="0">
                                        <tbody>
                                            <tr>
                                                <td style="word-break: break-word; padding: 10px; font-family: 'Montserrat', sans-serif;"
                                                    align="left">
                                                    <div style="text-align: center;">
                                                        <a href="https://epicridelondon.com/services"
                                                            style="padding: 5px 15px; display: inline-block; color: #fff; font-family: arial, helvetica, sans-serif; font-size: 14px; text-decoration: none;"
                                                            target="_blank">
                                                            <b>Services</b>
                                                        </a>

                                                        <a href="https://epicridelondon.com/fleets"
                                                            style="padding: 5px 15px; display: inline-block; color: #fff; font-family: arial, helvetica, sans-serif; font-size: 14px; text-decoration: none;"
                                                            target="_blank">
                                                           <b>Our Fleets</b>
                                                        </a>

                                                        <a href="https://epicridelondon.com/about-us"
                                                            style="padding: 5px 15px; display: inline-block; color: #fff; font-family: arial, helvetica, sans-serif; font-size: 14px; text-decoration: none;"
                                                            target="_blank">
                                                            <b>About Us</b>
                                                        </a>

                                                        <a href="https://epicridelondon.com/terms-&-conditions"
                                                            style="padding: 5px 15px; display: inline-block; color: #fff; font-family: arial, helvetica, sans-serif; font-size: 14px; text-decoration: none;"
                                                            target="_blank">
                                                            <b>Terms &amp; Conditions</b>
                                                        </a>
                                                    </div>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>

                                    <table style="font-family: 'Montserrat', sans-serif;" role="presentation"
                                        cellpadding="0" cellspacing="0" width="100%" border="0">
                                        <tbody>
                                            <tr>
                                                <td style="word-break: break-word; padding: 10px; font-family: 'Montserrat', sans-serif;"
                                                    align="left">
                                                    <table height="0px" align="center" border="0"
                                                        cellpadding="0" cellspacing="0" width="82%"
                                                        style="border-collapse: collapse; table-layout: fixed; border-spacing: 0; vertical-align: top; border-top: 1px solid #fff;">
                                                        <tbody>
                                                            <tr style="vertical-align: top;">
                                                                <td
                                                                    style="word-break: break-word; border-collapse: collapse !important; vertical-align: top; font-size: 0px; line-height: 0px;">
                                                                    <span>&nbsp;</span>
                                                                </td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>

                                    <table style="font-family: 'Montserrat', sans-serif;" role="presentation"
                                        cellpadding="0" cellspacing="0" width="100%" border="0">
                                        <tbody>
                                            <tr>
                                                <td style="word-break: break-word; padding: 0px 10px 13px; font-family: 'Montserrat', sans-serif;"
                                                    align="left">
                                                    <div
                                                        style="color: #fff; line-height: 180%; text-align: center; word-wrap: break-word;">
                                                        <p
                                                            style="font-size: 14px; line-height: 180%;font-weight: bold;">
                                                            © 2023 All Rights Reserved</p>
                                                    </div>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </td>
                            </tr>

                        </table>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</body>

</html>
