<?php

namespace App\Http\Controllers;

use App\Mail\diverRegisterMail;
use App\Mail\QuerryMail;
use Exception;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;

class QuerryController extends Controller
{
    //
    public function SendQuerry(Request $request)
    {
        if($request->firstName == null)
        {
              return response()->json((['success'=>false,'message'=>'first Name field is required']));
        }
        if($request->surName == null)
        {
            return response()->json((['success'=>false,'message'=>'sur Name field is required']));
        }
        if($request->postCode == null)
        {
            return response()->json((['success'=>false,'message'=>'postCode field is required']));
        }
        if($request->number == null)
        {
            return response()->json((['success'=>false,'message'=>'number field is required']));
        }
         if($request->clientStatus == null)
        {
            return response()->json((['success'=>false,'message'=>'clientStatus field is required']));
        }
        if($request->email == null)
        {
            return response()->json((['success'=>false,'message'=>'email field is required']));
        }
        if($request->confirmEmail == null)
        {
            return response()->json((['success'=>false,'message'=>'confirmEmail field is required']));
        }
        if($request->area == null)
        {
            return response()->json((['success'=>false,'message'=>'area field is required']));
        }
        if($request->meeting == null)
        {
            return response()->json((['success'=>false,'message'=>'meeting field is required']));
        }
        if($request->message == null)
        {
            return response()->json((['success'=>false,'message'=>'message field is required']));
        }
        if($request->option == null)
        {
            return response()->json((['success'=>false,'message'=>'option field is required']));
        }
        if($request->issue == null)
        {
            return response()->json((['success'=>false,'message'=>'issue field is required']));
        }
        try{
            $details = [
                'option'=>$request->option,
                'firstName'=> $request->firstName,
                'surName'=>$request->surName,
                'postCode'=>$request->postCode,
                'number'=> $request->number,
                'clientStatus'=> $request->clientStatus,
                'email'=> $request->email,
                'area'=> $request->area,
                'issue'=> $request->issue,
                'meeting'=> $request->meeting,
                'message'=> $request->message,
            ];
            Mail::to('shujat8300@gmail.com')->send(new diverRegisterMail($details));
            return response()->json((['success'=>true,'message'=>'Message Send Successfully']));
        } catch (Exception $e) {
            return response()->json([ "success"=>false,"error" => "internal Server error" ], 500);
        }

    }
}
