<?php

namespace App\Http\Controllers;

use Exception;
use App\Mail\contactUs;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;

class ContactucController extends Controller
{
    //
     //StoreContactUs
    public function StoreContactUs(Request $request)
    {
        if($request->name == null)
        {
              return response()->json((['success'=>false,'message'=>'first Name field is required']));
        }
        if($request->area == null)
        {
            return response()->json((['success'=>false,'message'=>'area field is required']));
        }
        if($request->email == null)
        {
            return response()->json((['success'=>false,'message'=>'Email field is required']));
        }
        if($request->message == null)
        {
            return response()->json((['success'=>false,'message'=>'Message field is required']));
        }
         if($request->number == null)
        {
            return response()->json((['success'=>false,'message'=>'number field is required']));
        }
        try{
            $details = [
                'name'=> $request->name,
                'area'=>$request->area,
                'email'=> $request->email,
                'message'=> $request->message,
                'number'=> $request->number,
            ];
            Mail::to('shujat8300@gmail.com')->send(new contactUs($details));
            return response()->json((['success'=>true,'message'=>'Message Send Successfully']));
        } catch (Exception $e) {
            return response()->json([ "success"=>false,"error" => "internal Server error" ], 500);
        }

    }
}
