<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Email Template</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;1,300;1,400;1,500;1,600;1,700;1,800&family=Rajdhani:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style type="text/css">
        body{
            font-family: 'Rajdhani', sans-serif !important;
        }
    </style>
</head>

<body style="padding: 0px;margin: 0px;">
    <div style="max-width:100%,width:100%;padding: 0px;">
        <table style="width: 100%;">
            <tbody>
                <tr>
                    <td>
                        <table style="width:700px;border: 1px solid gray;margin-left: auto;margin-right: auto;padding: 0px;border-spacing: 0px;">
                            <tr>
                                <td style="padding: 0px;">
                                    <div style="background-image:url(https://res.cloudinary.com/dyidzfrja/image/upload/v1680435519/personal/headimg_j9ctix.jpg);text-align: center;    background-repeat: no-repeat;background-position: center;height: 40vh;background-size: cover;">

                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td style="padding-left:50px;padding-right:50px;padding-top:50px;">
                                    <br>
                                    <p style="color: #777777;font-family: Arial;">
                                        <b>Dear</b> <?php echo e($details['firstName']); ?>,
                                    </p>
                                    <p style="color: #777777;font-family: Arial;">
                                       This user send you a message. </p>
                                    <p style="color: #777777;font-family: Arial;">
                                        The details are given below:
                                    </p>
                                </td>
                            </tr>
                            <tr>
                                <td style="padding:50px;">
                                    <table cellspacing="0" cellpadding="0" width="100%" >
                                        <tbody>
                                            <tr>
                                                <td style="padding: 0px 0px 5px 0px; font-weight: bold; color: #444444; border-bottom: dotted 1px #aaaaaa; text-transform: uppercase;font-family: Arial;">General</td>
                                            </tr>
                                            <tr>
                                                <td style="padding: 0px; height: 15px;"></td>
                                            </tr>
                                            <tr>
                                                <td style="padding: 0px;">
                                                    <table cellspacing="0" cellpadding="0">
                                                        <tbody>
                                                            <tr>
                                                                <td style="padding: 0px 5px 0px 0px; width: 250px; vertical-align: top;color: #777777"> Option</td>
                                                                <td style="padding: 0px 0px 0px 5px; width: 300px; vertical-align: top;color: #777777"><?php echo e($details['option']); ?></td>
                                                            </tr>
                                                            <tr>
                                                                <td style="padding: 0px 5px 0px 0px; width: 250px; vertical-align: top;color: #777777">First Name</td>
                                                                <td style="padding: 0px 0px 0px 5px; width: 300px; vertical-align: top;color: #777777"> <?php echo e($details['firstName']); ?></td>
                                                            </tr>
                                                            <tr>
                                                                <td style="padding: 0px 5px 0px 0px; width: 250px; vertical-align: top;color: #777777">Sur Name</td>
                                                                <td style="padding: 0px 0px 0px 5px; width: 300px; vertical-align: top;color: #777777"><?php echo e($details['surName']); ?></td>
                                                            </tr>
                                                            <tr>
                                                                <td style="padding: 0px 5px 0px 0px; width: 250px; vertical-align: top;color: #777777">Post Code</td>
                                                                <td style="padding: 0px 0px 0px 5px; width: 300px; vertical-align: top;color: #777777"><?php echo e($details['postCode']); ?></td>
                                                            </tr>
                                                            <tr>
                                                                <td style="padding: 0px 5px 0px 0px; width: 250px; vertical-align: top;color: #777777">Number</td>
                                                                <td style="padding: 0px 0px 0px 5px; width: 300px; vertical-align: top;color: #777777"><?php echo e($details['number']); ?></td>
                                                            </tr>
                                                            <tr>
                                                                <td style="padding: 0px 5px 0px 0px; width: 250px; vertical-align: top;color: #777777">Client Status</td>
                                                                <td style="padding: 0px 0px 0px 5px; width: 300px; vertical-align: top;color: #777777"><?php echo e($details['clientStatus']); ?></td>
                                                            </tr>
                                                            <tr>
                                                                <td style="padding: 0px 5px 0px 0px; width: 250px; vertical-align: top;color: #777777">Email</td>
                                                                <td style="padding: 0px 0px 0px 5px; width: 300px; vertical-align: top;color: #777777"><?php echo e($details['email']); ?></td>
                                                            </tr>
                                                            <tr>
                                                                <td style="padding: 0px 5px 0px 0px; width: 250px; vertical-align: top;color: #777777">Area</td>
                                                                <td style="padding: 0px 0px 0px 5px; width: 300px; vertical-align: top;color: #777777"><?php echo e($details['area']); ?></td>
                                                            </tr>
                                                            <tr>
                                                                <td style="padding: 0px 5px 0px 0px; width: 250px; vertical-align: top;color: #777777">Meeting</td>
                                                                <td style="padding: 0px 0px 0px 5px; width: 300px; vertical-align: top;color: #777777"><?php echo e($details['meeting']); ?></td>
                                                            </tr>
                                                            <tr>
                                                                <td style="padding: 0px 5px 0px 0px; width: 250px; vertical-align: top;color: #777777">Message</td>
                                                                <td style="padding: 0px 0px 0px 5px; width: 300px; vertical-align: top;color: #777777"><?php echo e($details['message']); ?></td>
                                                            </tr>
                                                            <tr>
                                                                <td style="padding: 0px 5px 0px 0px; width: 250px; vertical-align: top;color: #777777">Issue</td>
                                                                <td style="padding: 0px 0px 0px 5px; width: 300px; vertical-align: top;color: #777777"><?php echo e($details['issue']); ?></td>
                                                            </tr>





                                                        </tbody>
                                                    </table>
                                                </td>
                                            </tr>

                                        </tbody>
                                    </table>
                                </td>
                            </tr>
                            <tr>
                                <td style="padding-left:50px;padding-right:50px;">
                                    <table style="font-family:'Montserrat',sans-serif" cellpadding="0" cellspacing="0" width="100%" border="0">
                                        <tbody>
                                            <tr>
                                                <td style="word-break:break-word;padding:10px;font-family:'Montserrat',sans-serif" align="left">
                                                   <hr style="width:84%;">
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                    <table style="font-family:'Montserrat',sans-serif" cellpadding="0" cellspacing="0" width="100%" border="0">
                                        <tbody>
                                            <tr>
                                                <td style="word-break:break-word;padding:0px;font-family:'Montserrat',sans-serif" align="left">
                                                    <div style="line-height:140%;text-align:left;word-wrap:break-word">
                                                        <p style="font-size: 14px; line-height: 140%; text-align: left;color: #777777;">
                                                            
                                                            <span style="font-size: 14px; line-height: 19.6px;">
                                                                <strong>
                                                                    <span style="color: #000000; font-size: 14px; line-height: 19.6px;"><a  href="#" style="color: #000000;" target="_blank">Epic Chauffeur.</a></span>
                                                                </strong>
                                                            </span>
                                                            <br />
                                                            &nbsp;<br />
                                                            Warm Regards,<br />
                                                            Repla
                                                        </p>
                                                    </div>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </td>
                            </tr>
                            <tr>
                                <td style="padding: 30px 30px;
                                    background-image: url(https://res.cloudinary.com/dyidzfrja/image/upload/v1680435969/personal/london_mtl9u1.png);
                                    background-position: bottom;
                                    background-repeat: no-repeat;
                                    background-size: contain" bgcolor=" #C99B20">
                                    <table style="font-family: 'Montserrat', sans-serif;" role="presentation" cellpadding="0" cellspacing="0" width="100%" border="0">
                                        <tbody>
                                            <tr>
                                                <td style="word-break: break-word; padding: 0px 0px; font-family: 'Montserrat', sans-serif;" align="left">
                                                    <div style="color: #fff; line-height: 140%; text-align: center; word-wrap: break-word;">
                                                        <p style="font-size: 14px; line-height: 140%;">
                                                            
                                                        </p>
                                                    </div>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>

                                    <table style="font-family: 'Montserrat', sans-serif;" role="presentation" cellpadding="0" cellspacing="0" width="100%" border="0">
                                        <tbody>
                                            
                                        </tbody>
                                    </table>
                                    <table style="font-family: 'Montserrat', sans-serif;" role="presentation" cellpadding="0" cellspacing="0" width="100%" border="0">
                                        <tbody>
                                            
                                        </tbody>
                                    </table>

                                    <table style="font-family: 'Montserrat', sans-serif;" role="presentation" cellpadding="0" cellspacing="0" width="100%" border="0">
                                        <tbody>
                                            
                                        </tbody>
                                    </table>

                                    <table style="font-family: 'Montserrat', sans-serif;" role="presentation" cellpadding="0" cellspacing="0" width="100%" border="0">
                                        <tbody>
                                            
                                        </tbody>
                                    </table>

                                    <table style="font-family: 'Montserrat', sans-serif;" role="presentation" cellpadding="0" cellspacing="0" width="100%" border="0">
                                        <tbody>
                                            <tr>
                                                <td style="word-break: break-word; padding: 10px; font-family: 'Montserrat', sans-serif;" align="left">
                                                    <table
                                                        height="0px"
                                                        align="center"
                                                        border="0"
                                                        cellpadding="0"
                                                        cellspacing="0"
                                                        width="82%"
                                                        style="border-collapse: collapse; table-layout: fixed; border-spacing: 0; vertical-align: top; border-top: 1px solid #fff;"
                                                    >
                                                        <tbody>
                                                            <tr style="vertical-align: top;">
                                                                <td style="word-break: break-word; border-collapse: collapse !important; vertical-align: top; font-size: 0px; line-height: 0px;">
                                                                    <span>&nbsp;</span>
                                                                </td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>

                                    <table style="font-family: 'Montserrat', sans-serif;" role="presentation" cellpadding="0" cellspacing="0" width="100%" border="0">
                                        <tbody>
                                            <tr>
                                                <td style="word-break: break-word; padding: 0px 10px 13px; font-family: 'Montserrat', sans-serif;" align="left">
                                                    <div style="color: #fff; line-height: 180%; text-align: center; word-wrap: break-word;">
                                                        <p style="font-size: 14px; line-height: 180%;font-weight: bold;">© 2023 All Rights Reserved</p>
                                                    </div>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </td>
                            </tr>

                        </table>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</body>

</html>
<?php /**PATH E:\xampp\htdocs\MailProject\resources\views/emails/querryMail.blade.php ENDPATH**/ ?>